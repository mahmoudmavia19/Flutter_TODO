package com.example.mycourse

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
