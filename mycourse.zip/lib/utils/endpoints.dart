class TableEndpoints {
  static String tTask = 'Task';
}

class FirebaseEndpoints {
  static String users = 'users';

}